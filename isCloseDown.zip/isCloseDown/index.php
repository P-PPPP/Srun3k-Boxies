<?php
    include_once("func.php");
    if($_GET["mode"]==1 || $_GET["mode"] == "1"){
        echo    "<h1>修了，等会嗷</h1>";
        fix();
        echo    "<script>window.location.href='./index.php'</script>";
    }
    elseif($_GET["mode"]==2 || $_GET["mode"] == "2"){auto();}
    elseif($_GET["mode"]==3 || $_GET["mode"] == "3"){Fresh();}
    else{}
    class returning{
        var $status;
        var $detail;
    }
    function Stage(){
        $Check = "mwan3 status";
        //exec($Check,$result,$status);
        $status = 0;
        $myfile = fopen("./test.txt","r");
        $result = explode("\n",fread($myfile,filesize("./test.txt")));
        fclose($myfile);
        $returning = new returning();
        if(!$status){
            $returning -> status = 1;
            for($i = 0;$i<count($result);$i++){
                if(strpos($result[$i],"ipv4 policies")==true){
                    $returning -> detail = array_slice($result,0,$i);
                    break;
                }
            }
            
        }else{
            $returning -> status = 0;
        }
        return $returning;
    }

    function isDOwn(){
        $returning = Stage();
        $online = 0;
        $detail = "";
        for($i=0;$i<count($returning->detail);$i++){
            if(strstr($returning->detail[$i],"online")){
                $online+=1;     
            }
            $detail .=$returning -> detail[$i]."\n";
        }
        if($online){$status = 1;}else{$status=0;}
        echo    '<div id="status" style="display:none;" >'.$status.'</div>';
        echo    '<div id="phpDetail" style="display:none;" ><p>'.$online."在线</p>".$detail.'</div>';
        //return $status;
    }
    isDOwn();
?>
<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="source/css/bootstrap.min.css">
    <script src="source/js/jquery-3.6.0.min.js"></script>
    <script src="source/js/bootstrap.min.js"></script>
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Close 倒了?</title>
    <script>
        function isDown(){
            var status = document.getElementById('status').innerHTML;
            document.getElementById("detail").innerHTML = document.getElementById("phpDetail").innerHTML;
            if(status == 1 || status == "1"){
                document.getElementById("no").style.display = "block";
            }else{
                document.getElementById("yes").style.display = "block";
            }
        }
    </script>
    </head>

    <body onload="isDown();">
        <div id="no" style="display:none;">
            <h1 id="statusShow">没倒!</h1>
                <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                查看详情
                </button>
                <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" onclick="window.location.href='./index.php?mode=3'">
                刷新
                </button>
                <div class="collapse" id="collapseExample">
                    <div class="well" id="detail">
                        ...
                    </div>
                </div>
        </div>

        <div id="yes" style="display:none;">
            <h1 id="statusShow">倒了!</h1>
                <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                查看详情
                </button>
                <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" onclick="window.location.href='./index.php?mode=1'">
                修!
                </button>
                <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" onclick="window.location.href='./index.php?mode=2'">
                托管模式
                </button>
                <div class="collapse" id="collapseExample">
                    <div class="well" id="detail">
                        ...
                    </div>
                </div>
        </div>


    </body>
</html>