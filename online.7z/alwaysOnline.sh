 #!/bin/bash
 while [ true ]
 do
	 /bin/sleep 1
	 data =	`python3 ./alwaysOnline.py`
 done