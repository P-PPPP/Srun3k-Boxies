import os,sys
import gen as G

with os.popen("mwan3 status") as s:
    status = s.read()
    s.close()
conuts = status.count("online")
print("with %s online" %conuts)
if conuts <14:
    commands = G.obj().genera()
    #print(commands)
    os.system(commands)
