<?php

    function Fresh(){
        exec("python3 /www/close/getinfo.py",$result,$status);
    }

    function fix(){
        exec("python3 /root/alwaysOnline.py",$result,$status);
    }

    function auto(){
        exec("nohup & /root/alwaysOnline.sh",$result,$status);
    }
?> 