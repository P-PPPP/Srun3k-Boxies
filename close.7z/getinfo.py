import os,sys

with os.popen("mwan3 status") as s:
    status = s.read()
    s.close()
with open("./test.txt","w") as f:
	f.write(status)